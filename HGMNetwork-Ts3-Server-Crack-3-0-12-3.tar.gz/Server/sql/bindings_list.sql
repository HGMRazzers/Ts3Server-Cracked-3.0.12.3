select * from bindings where type = :type:;
